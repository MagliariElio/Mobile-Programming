package it.mem.comuni.adapters


import android.content.Context
import android.content.Intent
import android.content.res.Resources
import android.graphics.Color
import android.net.Uri
import android.util.Log
import android.view.LayoutInflater
import android.widget.Filter
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import androidx.core.content.ContextCompat.startActivity
import androidx.recyclerview.widget.RecyclerView
import it.mem.comuni.R
import it.mem.comuni.databinding.LeftBinding
import it.mem.comuni.models.Comune
import it.mem.comuni.models.ListaComuni
import java.net.URI
import java.util.*

@Suppress("SpellCheckingInspection")
class AdapterComuni(contesto:Context,placesList: ListaComuni):
    RecyclerView.Adapter<AdapterComuni.ViewHolder>() {
    private var allPlacesList = ListaComuni()
    private var filteredPlacesList = ListaComuni()
    private lateinit var binding: LeftBinding
    private var context=contesto



    init {
        allPlacesList =placesList
        filteredPlacesList = allPlacesList
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val layoutInflater = LayoutInflater.from(parent.context)

        binding = LeftBinding.inflate(layoutInflater, parent, false)
        return ViewHolder(context, binding)
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        if(position%3==0) {
            binding.cvComune.setCardBackgroundColor(Color.parseColor("#81C9A4"))
            binding.tvLink.setTextColor(Color.WHITE)
        }
        else if (position%3==1){
            binding.cvComune.setCardBackgroundColor(Color.WHITE)
        }

        else  {
            binding.cvComune.setCardBackgroundColor(Color.parseColor("#DF7981"))
            binding.tvLink.setTextColor(Color.WHITE)
        }

        holder.comune = filteredPlacesList[position]
    }

    override fun getItemCount(): Int {
        return filteredPlacesList.listaComuni.size
    }

    override fun getItemViewType(position: Int): Int {
        return position
    }

    @Suppress("unused")
    fun getFilter(): Filter{
        return object : Filter(){
            override fun publishResults(charSequence: CharSequence?, filterResults: FilterResults){
                filteredPlacesList = filterResults.values as ListaComuni
                notifyDataSetChanged()
            }

            override fun performFiltering(charSequence: CharSequence?): FilterResults{
                val queryString = charSequence?.toString()?.toUpperCase(Locale.getDefault())

                val filterResults = FilterResults()

                filterResults.values = if(queryString == null || queryString.isEmpty())
                    allPlacesList
                else
                    allPlacesList.filter{
                        it.comune.toUpperCase(Locale.getDefault()).startsWith(queryString)
                    }

                return filterResults
            }
        }

    }

    class ViewHolder(context: Context, binding: LeftBinding):RecyclerView.ViewHolder(binding.root){
        private val contesto = context
        var comune: Comune = Comune()
            set(value) {
                field =value
                tvComune.text = value.comune
                tvLink.text = value.link.toLowerCase(Locale.getDefault())
                tvProvincia.text = String.format("(%s)",
                    value.provincia.toUpperCase(Locale.getDefault()))
                tvCap.text=value.cap
                tvAbitanti.text=value.abitanti
                tvPrefisso.text=value.prefisso

                tvLink.setOnClickListener {
                    val url=tvLink.text.toString()
                    val intent=Intent(Intent.ACTION_VIEW)
                    intent.data = Uri.parse(url)
                    startActivity(contesto, intent, null)
                }
                /*val sigla:Uri
                val intero:Int = contesto.resources.getIdentifier("R.drawable."+ (value.regione).toLowerCase(),"drawable", contesto.getString())
                sigla = Uri.parse("android.resource://it.mem.comuni/$intero")
                Log.w("LUCI",sigla.toString())
                Log.w("LUCI", "${R.drawable.laz}")
                ivStemma.setImageURI(sigla)
                */
                when (value.regione) {
                    "LAZ" -> ivStemma.setImageResource(R.drawable.laz)
                    "ABR" -> ivStemma.setImageResource(R.drawable.abr)
                    "CAL" -> ivStemma.setImageResource(R.drawable.cal)
                    "BAS" -> ivStemma.setImageResource(R.drawable.bas)
                    "CAM" -> ivStemma.setImageResource(R.drawable.cam)
                    "EMR" -> ivStemma.setImageResource(R.drawable.emr)
                    "FVG" -> ivStemma.setImageResource(R.drawable.fvg)
                    "LIG" -> ivStemma.setImageResource(R.drawable.lig)
                    "LOM" -> ivStemma.setImageResource(R.drawable.lom)
                    "MOL" -> ivStemma.setImageResource(R.drawable.mol)
                    "MAR" -> ivStemma.setImageResource(R.drawable.mar)
                    "TAA" -> ivStemma.setImageResource(R.drawable.taa)
                    "PIE" -> ivStemma.setImageResource(R.drawable.pie)
                    "TOS" -> ivStemma.setImageResource(R.drawable.tos)
                    "PUG" -> ivStemma.setImageResource(R.drawable.pug)
                    "SIC" -> ivStemma.setImageResource(R.drawable.sic)
                    "VEN" -> ivStemma.setImageResource(R.drawable.ven)
                    "VDA" -> ivStemma.setImageResource(R.drawable.vda)
                    "UMB" -> ivStemma.setImageResource(R.drawable.umb)
                    "SAR" -> ivStemma.setImageResource(R.drawable.sar)
                }


            }


        private var tvComune: TextView = binding.tvComune
        private var tvLink: TextView = binding.tvLink
        private var tvProvincia: TextView = binding.tvProvincia
        private var tvCap: TextView = binding.tvCap
        private var tvAbitanti: TextView = binding.tvAbitanti
        private var tvPrefisso: TextView = binding.tvPrefisso
        private var ivStemma: ImageView = binding.imageView


    }

}